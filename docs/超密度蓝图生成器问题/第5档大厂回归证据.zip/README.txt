本包为第5档极区大厂占位优化的追加证据，不代表总体目标完成。

regression.jsonl：临时Go overlay加载验收源码执行 go test ./... -count=1 -timeout=15m -json 的原始结果。
regression-summary.json：9项顶层测试、413项子测试通过，包含第5档144组整厂及既有纬带回归。
packed-183.json、packed--247.json、stress-layout.png：构造的384台制造台建筑占位用例，独立逐盒检查通过；不包含完整生产物流。
baseline.log、indexed.log：固定单并发的占位剖析对照；都没有成功生成运输船蓝图。
production-ship.log、production-performance.json：实际默认并发、4分钟总时限，运输船60/min未通过。
extended-ship.log、extended-performance.json：仅诊断时通过临时overlay延长到8分钟，仍未通过；应用时限未修改。
ship-plan.json、receipt.json：实际全链配置、设备数量、源码与构建摘要。

本包不包含测试源码、诊断程序、CPU二进制或失败的部分蓝图。原有144份可复验蓝图见同目录的第5档验收样例.zip。
