import json,pathlib,collections
root=pathlib.Path('.tmp/coil200-20261111')
for folder in ['baseline','final']:
 d=json.loads((root/folder/'decoded.json').read_text(encoding='utf-8-sig')); r=json.loads((root/folder/'result.json').read_text(encoding='utf-8-sig'))
 ports=r['logisticsSummary']['externalPorts'];print(folder, 'ports',len(ports),'ys',min(p['y'] for p in ports),max(p['y'] for p in ports),'layers',dict(collections.Counter(p['z'] for p in ports if p['kind']=='external-input')))
 f={'areas':[{'index':a['index'],'parentIndex':a['parentIndex'],'anchorX':a['anchorLocalOffsetX'],'anchorY':a['anchorLocalOffsetY'],'width':a['width'],'height':a['height']} for a in d['areas']],'buildings':[]}
 for b in d['buildings']:
  p=b['localOffset'];q=b['localOffset2']
  n={'itemId':b['itemId'],'modelIndex':b['modelIndex'],'x':p['x'],'y':p['y'],'z':p['z'],'x2':q['x'],'y2':q['y'],'z2':q['z'],'yaw':b['yaw'],'areaIndex':b['areaIndex'],'index':b['index']}
  if b['outputObjIdx']>=0:n['outputId']='b'+str(b['outputObjIdx'])
  if b['inputObjIdx']>=0:n['inputId']='b'+str(b['inputObjIdx'])
  f['buildings'].append(n)
 (pathlib.Path('frontend/.tmp-coil200')/(folder+'.json')).write_text(json.dumps(f,separators=(',',':')),encoding='utf-8')



