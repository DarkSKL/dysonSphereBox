package build
import("context";"math";"testing")

// TestForwardPortalSurvivesLimit 从四个方向验证两候选截断不会丢失合法直出；直出被占时仍保留侧移退路。
func TestForwardPortalSurvivesLimit(t *testing.T){
 for _,direction:=range []vector{{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}}{
  b,err:=newBuilder(Setting{BeltLv:3,InserterLv:3});if err!=nil{t.Fatal(err)}
  source:=b.make(2003,0,0,0);target:=b.make(2003,8,8,0)
  index,err:=b.newDenseRoutePortIndex(context.Background());if err!=nil{t.Fatal(err)}
  index.boundary=&denseBoundaryLayout{minimumX:-10,maximumX:2,minimumY:-10,maximumY:10};env:=&transportEnvironment{densePorts:index,minimum:vector{-10,-10,0},maximum:vector{10,10,32},reserved:map[vector]map[*placed]bool{}}
  portals:=env.densePortals(source,source,target,direction,true,false,0)
  found:=false;for _,p:=range portals{end:=p.points[len(p.points)-1];found=found||end==direction}
  if !found{t.Fatal("straight exit was pruned",direction,portals)}
  block:=b.make(2003,direction.x,direction.y,0);index.addNode(block)
  portals=env.densePortals(source,source,target,direction,true,false,0)
  if len(portals)==0{t.Fatal("no fallback around blocked straight exit",direction)}
  for _,p:=range portals{if p.points[len(p.points)-1]==direction{t.Fatal("blocked exit accepted")}}
 }
}

// TestGroundBoundaryCompaction 保留物料与行号，只缩短净空充足的单层接口；多层和真实建筑挡路均必须保留原方案。
func TestGroundBoundaryCompaction(t *testing.T){
 for _,test:=range []struct{name string;upper,obstacle bool;want float64}{{"ground",false,false,-3},{"layered",true,false,-7},{"obstacle",false,true,-7}}{
  t.Run(test.name,func(t *testing.T){
   b,err:=newBuilder(Setting{BeltLv:3,InserterLv:3});if err!=nil{t.Fatal(err)}
   if test.obstacle{b.make(2303,-2,4,0)}
   out:=&transportRoute{};plan:=&denseBoundaryLayout{minimumX:-7,handoffX:-4,levelLimitX:-3.5,maximumX:-.5,minimumY:0,maximumY:10,outputs:map[*transportRoute]vector{out:{-7,8,0}}}
   inputs:=[]vector{{-7,4,0}};if test.upper{inputs[0].z=2}
   if err:=b.compactDenseGroundBoundary(context.Background(),plan,inputs,0);err!=nil{t.Fatal(err)}
   if plan.minimumX!=test.want||inputs[0].x!=test.want||plan.outputs[out].x!=test.want||inputs[0].y!=4||math.Abs(plan.outputs[out].y-8)>1e-9{t.Fatal("unexpected compacted boundary",plan,inputs)}
  })
 }
}

