import json,pathlib,collections
root=pathlib.Path('.tmp/energy-1500-20261111')
out={}
for folder in ['signal60-stone-baseline','signal60-internal','signal60-internal-monitors','boundary-energy1500-final']:
 caseRoot=root/folder
 r=json.loads((caseRoot/'result.json').read_text(encoding='utf-8-sig'));d=json.loads((caseRoot/'decoded.json').read_text(encoding='utf-8-sig'));q=json.loads((caseRoot/'request.json').read_text(encoding='utf-8-sig'))
 ports={p['buildingIndex']:p for p in r['logisticsSummary']['externalPorts']};inputs={i:p for i,p in ports.items() if p['kind']=='external-input'}
 bounds=lambda values:[min(values),max(values)]
 raw={}; layers=collections.Counter()
 for i,p in inputs.items(): raw[p['itemId']]=raw.get(p['itemId'],0)+p['ratePerMinute']; layers[p['z']]+=1
 out[folder]={'planId':q['plan'].get('planId'),'entities':len(d['buildings']),'metrics':r['logisticsSummary']['metrics'],'elapsed':json.loads((caseRoot/'elapsed.json').read_text()),'physicalInputs':len(inputs),'inputLayers':dict(layers),'interfaceY':bounds([p['y'] for p in ports.values()]),'inputFlows':raw,'outputPorts':[{k:p[k] for k in ['itemId','ratePerMinute','x','y','z','kind']} for p in ports.values() if p['kind']!='external-input'],'checks':[c for c in r['logisticsSummary']['checks'] if c['ruleId']=='dense-boundary-separation']}
(root/'boundary-comparison.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:{'entities':v['entities'],'ms':v['elapsed']['ms'],'physicalInputs':v['physicalInputs'],'inputLayers':v['inputLayers'],'interfaceY':v['interfaceY']} for k,v in out.items()},indent=2))


