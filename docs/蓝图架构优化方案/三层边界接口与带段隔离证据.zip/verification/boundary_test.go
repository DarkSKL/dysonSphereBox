package build

import (
 "context"
 "math"
 "math/rand"
 "testing"
)

// TestBoundaryAssignmentOracle 用穷举独立核对小问题的最小位移和升层代价，防止槽重复或丢原料。
func TestBoundaryAssignmentOracle(t *testing.T) {
 r:=rand.New(rand.NewSource(2818))
 for c:=0;c<100;c++ {
  rows:=1+r.Intn(3); reserved:=map[int]bool{}
  if r.Intn(2)==0 { reserved[r.Intn(rows)]=true }
  n:=1+r.Intn(min(5,3*rows-len(reserved))); desired:=make([]vector,n)
  for i:=range desired { desired[i]=vector{-5,r.Float64()*8-2,0} }
  got,err:=matchDenseBoundarySlots(context.Background(),desired,0,2,rows,reserved);if err!=nil{t.Fatal(err)}
  slots:=[]vector{}; for row:=0;row<rows;row++ {for z:=0;z<=4;z+=2 {if z!=0||!reserved[row]{slots=append(slots,vector{-5,float64(2*row),float64(z)})}}}
  used:=make([]bool,len(slots)); best:=math.Inf(1)
  var visit func(int,float64); visit=func(i int,cost float64){if cost>=best{return};if i==n{best=cost;return};for j,p:=range slots{if !used[j]{used[j]=true;visit(i+1,cost+math.Abs(desired[i].y-p.y)+p.z*2);used[j]=false}}};visit(0,0)
  cost:=0.; seen:=map[vector]bool{}
  for i,p:=range got { if seen[p]||p.x!=-5||p.z<0||p.z>4||math.Mod(p.z,2)!=0||p.y<0||p.y>float64((rows-1)*2)||p.z==0&&reserved[int(p.y/2)]{t.Fatal("invalid unique slot",c,p)};seen[p]=true;cost+=math.Abs(desired[i].y-p.y)+p.z*2 }
  if math.Abs(cost-best)>1e-8{t.Fatal("nonoptimal assignment",c,cost,best)}
 }
 cancelled,cancel:=context.WithCancel(context.Background());cancel()
 if _,err:=matchDenseBoundarySlots(cancelled,[]vector{{}},0,2,1,nil);err==nil{t.Fatal("cancellation ignored")}
 if _,err:=matchDenseBoundarySlots(context.Background(),make([]vector,4),0,2,1,nil);err==nil{t.Fatal("capacity exceeded")}
}

// TestBoundaryCollisionMutations 区分真正相交、合法分层、共享节点和同坐标假合流。
func TestBoundaryCollisionMutations(t *testing.T) {
 layout:=&denseBoundaryLayout{minimumX:-6,maximumX:-.5,minimumY:0,maximumY:10}
 cases:=[]struct{name string; points []vector; edges [][2]int; fail bool}{
  {"crossing",[]vector{{-5,2,0},{-3,2,0},{-4,1,0},{-4,3,0}},[][2]int{{0,1},{2,3}},true},
  {"layered",[]vector{{-5,2,0},{-3,2,0},{-4,1,2},{-4,3,2}},[][2]int{{0,1},{2,3}},false},
  {"merge",[]vector{{-5,2,0},{-4,2,0},{-4,3,0}},[][2]int{{0,1},{2,1}},false},
  {"false merge",[]vector{{-5,2,0},{-4,2,0},{-4,3,0},{-4,2,0}},[][2]int{{0,1},{2,3}},true},
  {"fourth layer",[]vector{{-5,2,6},{-4,2,6}},[][2]int{{0,1}},true},
  {"intermediate horizontal",[]vector{{-5,2,1},{-4,2,1}},[][2]int{{0,1}},true},
  {"ramp",[]vector{{-5,2,0},{-4,2,1},{-3,2,2}},[][2]int{{0,1},{1,2}},false},
  {"long tail",[]vector{{-5,2,0},{-5,12,0}},[][2]int{{0,1}},true},
  {"backtracking outside",[]vector{{-5,2,0},{-7,2,0}},[][2]int{{0,1}},true},
  {"factory unaffected",[]vector{{1,2,6},{4,2,6},{3,1,6},{3,3,6}},[][2]int{{0,1},{2,3}},false},
 }
 for _,c:=range cases{t.Run(c.name,func(t *testing.T){b:=&builder{denseBoundary:layout};for _,p:=range c.points{b.make(2001,p.x,p.y,p.z)};for _,e:=range c.edges{connect(b.all[e[0]],b.all[e[1]])};if err:=b.validateDenseBoundaryRoutes(context.Background());(err!=nil)!=c.fail{t.Fatal("unexpected validation",err)}})}
}

// TestBoundaryStemIdentity 保留唯一真实外供头和完整有向前缀，避免容量切片身份被寻路端点覆盖。
func TestBoundaryStemIdentity(t *testing.T){
 b:=&builder{setting:Setting{BeltLv:1},denseBoundary:&denseBoundaryLayout{handoffX:-2}}
 first:=b.make(2001,-5,3,2); route:=&transportRoute{start:first,boundary:first,path:[]*placed{first}}
 b.appendDenseInputStem(route)
 if route.start!=first||route.boundary!=first||route.transportSource().a!=(vector{-2,3,2})||len(route.path)!=4{t.Fatal("identity or extent changed")}
 for i:=1;i<len(route.path);i++{if route.path[i-1].output!=route.path[i]||route.path[i].a.x-route.path[i-1].a.x!=1{t.Fatal("broken prefix")}}
 if (&transportRoute{start:first}).transportSource()!=first{t.Fatal("ordinary source changed")}
}
// TestBoundaryEscapeReservations 预留仅属于自身的两格短出路，保持不同层可并行，厂内不扩大整列。
func TestBoundaryEscapeReservations(t *testing.T){
 a:=&placed{a:vector{-2,3,0}};b:=&placed{a:vector{-2,3,2}}
 env:=&transportEnvironment{reserved:map[vector]map[*placed]bool{},densePorts:&denseRoutePortIndex{boundary:&denseBoundaryLayout{}}}
 env.reserveDenseBoundaryEscapes([]*transportRoute{{routingEntry:a},{routingEntry:b}})
 for _,source:=range []*placed{a,b}{for step:=1.;step<=2;step++{p:=vector{source.a.x+step,3,source.a.z};if env.reservedByOther(p,source,nil)||!env.reservedByOther(p,nil,nil){t.Fatal("reservation ownership lost")}}}
 if len(env.reserved)!=4||env.reservedByOther(vector{-1,3,1},nil,nil)||env.reservedByOther(vector{1,3,0},nil,nil){t.Fatal("reservation widened")}
}
// TestBoundaryRoutingOrder 先保留厂内接线，再由低到高接入外供；同层保持原先的容量份额次序。
func TestBoundaryRoutingOrder(t *testing.T){
 input:=func(z float64)*transportRoute{return &transportRoute{routingEntry:&placed{a:vector{z:z}}}}
 high,low,mid,low2:=input(4),input(0),input(2),input(0)
 internal1,internal2:=&transportRoute{},&transportRoute{}
 routes:=[]*transportRoute{internal1,high,low,internal2,mid,low2}
 b:=&builder{denseBoundary:&denseBoundaryLayout{}};b.orderDenseBoundaryRoutes(routes)
 want:=[]*transportRoute{internal1,internal2,low,low2,mid,high}
 for i:=range want{if routes[i]!=want[i]{t.Fatal("changed stable internal or layer ordering",i)}}
}

// TestBoundaryTransitionClearance 盒外过渡允许升降，但不能因此放行不同物料路线的真实相交。
func TestBoundaryTransitionClearance(t *testing.T){
 layout:=&denseBoundaryLayout{minimumX:-7,maximumX:-.5,levelLimitX:-3.5,minimumY:0,maximumY:10}
 index:=&denseRoutePortIndex{boundary:layout}
 if !index.boundarySpanAllowed(vector{-2,2,5},vector{-1,2,5})||index.boundarySpanAllowed(vector{-5,2,5},vector{-4,2,5}){t.Fatal("entry and transition height limits mixed")}
 b:=&builder{denseBoundary:layout}
 for _,v:=range []vector{{-3,2,5},{-1,2,5},{-2,1,5},{-2,3,5}}{b.make(2001,v.x,v.y,v.z)}
 connect(b.all[0],b.all[1]);connect(b.all[2],b.all[3]);if b.validateDenseBoundaryRoutes(context.Background())==nil{t.Fatal("transition overlap accepted")}
}

