import {createAlgorithmViz, ALGORITHM_VIZ_MODEL_KEYS} from '../src/packages/algorithm-viz/src'
import basisJs from 'three/examples/jsm/libs/basis/basis_transcoder.js?url'
import basisWasm from 'three/examples/jsm/libs/basis/basis_transcoder.wasm?url'
const files=import.meta.glob('../src/data/models/*.glb',{as:'url',eager:true})
const masks=import.meta.glob('../src/data/models/masks/mask-*.png',{as:'url',eager:true})
const modelUrls: Record<string,string>={},maskUrls:Record<string,string>={}
for(const [path,url] of Object.entries(files)){const key=path.slice(path.lastIndexOf('/')+1,-4);if(ALGORITHM_VIZ_MODEL_KEYS.includes(key as never))modelUrls[key]=url}
for(const [path,url] of Object.entries(masks))maskUrls[path.slice(path.lastIndexOf('mask-')+5,-4)]=url
const root=window as any
const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms))
const until=async(fn:()=>boolean)=>{const start=performance.now();while(!fn()){if(performance.now()-start>120000)throw Error('render timeout '+JSON.stringify(root.viz.getProgress()));await delay(50)}}
async function run(){
 const fixture=await(await fetch('./'+(new URLSearchParams(location.search).get('case')||'signal60-boundary-final')+'.json')).json();let selected:any=null
 const viz=createAlgorithmViz(document.getElementById('view')!,{quality:'low',theme:'light',speed:8,modelUrls,maskUrls,transcoderUrls:{js:basisJs,wasm:basisWasm},onSelect:value=>{selected=value},onStats:value=>{root.stats=value}});root.viz=viz
 if(!viz.supported)throw Error('WebGL unavailable')
 const start=performance.now();viz.caption('信号塔 60/min · 一级带 · '+(location.search.includes('baseline')?'修复前':'三层接口修复后'),`${fixture.buildings.length} 个建筑 · 完整蓝图回放`)
 for(let i=0;i<fixture.buildings.length;i+=1024){viz.enqueue({coordinates:'area',areas:fixture.areas,operations:fixture.buildings.slice(i,i+1024).map((building:any)=>({type:'add',id:'b'+building.index,building}))});await delay(0)}
 viz.flush();await until(()=>viz.getProgress().pending===0&&viz.getProgress().animating===0&&viz.getProgress().objects===fixture.buildings.length)
 const loadMs=performance.now()-start;viz.select('b'+(fixture.buildings.length-1));if(selected?.building.index!==fixture.buildings.length-1)throw Error('last object is missing');viz.select(null)
 await delay(1500);root.result={passed:true,buildingCount:fixture.buildings.length,loadMs,progress:viz.getProgress(),stats:root.stats};
}
run().catch(e=>{root.result={passed:false,error:String(e),stack:e.stack,progress:root.viz?.getProgress()}})


