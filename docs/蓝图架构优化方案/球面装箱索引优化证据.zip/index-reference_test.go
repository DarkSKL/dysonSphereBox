package build
import("math";"DysonSphereBox/helper/blueprint/build/placement")
type referencePolarSpatialIndex struct {
	cells    map[[3]int][]int
	marks    []uint32
	sequence uint32
}

// referencePolarSpatialCells 职责：遍历包围盒覆盖的全部桶；使用：登记和查询；边界：边界桶也包含在内，visit返回false时提前停止。
func referencePolarSpatialCells(low, high placement.Vector, visit func([3]int) bool) bool {
	for x := int(math.Floor(low[0] / polarSpatialCellSize)); x <= int(math.Floor(high[0]/polarSpatialCellSize)); x++ {
		for y := int(math.Floor(low[1] / polarSpatialCellSize)); y <= int(math.Floor(high[1]/polarSpatialCellSize)); y++ {
			for z := int(math.Floor(low[2] / polarSpatialCellSize)); z <= int(math.Floor(high[2]/polarSpatialCellSize)); z++ {
				if !visit([3]int{x, y, z}) {
					return false
				}
			}
		}
	}
	return true
}

// add 职责：登记一个新对象并保留原集合下标；使用：单元确认落位之后；边界：登记顺序须与对应几何数组一致。
func (index *referencePolarSpatialIndex) add(low, high placement.Vector) {
	if index.cells == nil {
		index.cells = map[[3]int][]int{}
	}
	id := len(index.marks)
	index.marks = append(index.marks, 0)
	referencePolarSpatialCells(low, high, func(cell [3]int) bool { index.cells[cell] = append(index.cells[cell], id); return true })
}

// any 职责：仅对宽相位命中的唯一对象执行原精确判定；使用：盒、节点和臂查询；边界：毫米外扩只增加候选，不放宽精确距离阈值。
func (index *referencePolarSpatialIndex) any(low, high placement.Vector, conflict func(int) bool) bool {
	if len(index.marks) == 0 {
		return false
	}
	index.sequence++
	if index.sequence == 0 {
		clear(index.marks)
		index.sequence = 1
	}
	margin := placement.Vector{.001, .001, .001}
	found := false
	referencePolarSpatialCells(low.Sub(margin), high.Add(margin), func(cell [3]int) bool {
		for _, id := range index.cells[cell] {
			if index.marks[id] == index.sequence {
				continue
			}
			index.marks[id] = index.sequence
			if conflict(id) {
				found = true
				return false
			}
		}
		return true
	})
	return found
}

