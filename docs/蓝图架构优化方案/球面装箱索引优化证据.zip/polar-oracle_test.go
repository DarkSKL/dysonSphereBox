package build
import("context";"fmt";"math";"math/rand";"reflect";"sync/atomic";"testing";"time";"DysonSphereBox/helper/quant";"DysonSphereBox/helper/blueprint/build/placement")
var oraclePacks atomic.Int64
func (b *builder) packPolarUnitGeometry(ctx context.Context, units []denseSpatialUnit, precise bool)(*denseSpatialUnit,error){
 before:=make([]placed,len(b.all));for i,p:=range b.all {before[i]=*p}
 oldBlocked,oldErr:=b.packPolarUnitGeometryReference(ctx,units,precise)
 expected:=make([]placed,len(b.all));for i,p:=range b.all{expected[i]=*p;*p=before[i]}
 blocked,err:=b.packPolarUnitGeometryIndexed(ctx,units,precise)
 if ctx.Err()!=nil{return blocked,err}
 if fmt.Sprint(err)!=fmt.Sprint(oldErr)||!reflect.DeepEqual(blocked,oldBlocked){panic(fmt.Sprintf("packing outcome changed: %v / %v",err,oldErr))}
 for i,p:=range b.all{if !reflect.DeepEqual(*p,expected[i]){panic(fmt.Sprintf("packing entity %d changed",i))}}
 oraclePacks.Add(1);return blocked,err
}
func TestPolarPackingOracle(t *testing.T){
 for _,c:=range []struct{item int;rate float64;zone string}{{6001,3000,"equator"},{6001,3000,"ring3-north-south"},{6002,1000,"equator"},{2103,6,"equator"}}{
 t.Run(fmt.Sprint(c),func(t *testing.T){ctx,cancel:=context.WithTimeout(context.Background(),90*time.Second);defer cancel();d,_:=quant.LoadDataset("Vanilla");fixed:=2;space:=1.;spray:=false
 p,e:=quant.Solve(ctx,quant.Request{Dataset:"Vanilla",Targets:[]quant.Target{{ItemID:c.item,RatePerMinute:c.rate}},Settings:quant.Settings{MiningSpeedMultiple:1,FixedNum:&fixed,ProliferateItself:&spray,StackResearchLab:3,MineralizeList:map[string]bool{d.ByID[1003].Name:true}},Scheme:quant.Scheme{ItemRecipeChoices:map[string]int{},SchemeForRecipe:make([]quant.RecipeScheme,len(d.Recipes)),CostWeight:quant.CostWeight{Space:&space}}});if e!=nil{t.Fatal(e)}
 n:=oraclePacks.Load();routed:=false;ctx=WithProgress(ctx,func(p Progress){if p.Stage=="routing" {routed=true;cancel()}})
 _,e=Generate(ctx,Request{Plan:p,Mode:1,Density:"dense",Setting:Setting{BeltLv:1,InserterLv:1,MaxLays:3},SurfaceLayout:&SurfaceLayout{Mode:"explicitTropic",GridSegment:200,LatitudeZone:c.zone},CandidateConcurrency:1})
 if !routed||oraclePacks.Load()<=n{t.Fatal("packing not exercised",e)};t.Log("identical packing",oraclePacks.Load()-n)
 })}
}
func TestPolarIndexAgainstExactGeometry(t *testing.T){
 random:=rand.New(rand.NewSource(92317));boxes:=make([]placement.Box,1200);idx:=polarSpatialIndex{}
 for i:=range boxes{a:=random.Float64()*math.Pi*2;s,c:=math.Sincos(a);box:=placement.Box{Center:placement.Vector{random.Float64()*120-60,random.Float64()*40-20,random.Float64()*120-60},HalfSize:placement.Vector{.01+random.Float64()*4,.01+random.Float64()*4,.01+random.Float64()*4},Axes:[3]placement.Vector{{c,0,s},{0,1,0},{-s,0,c}}};boxes[i]=box;lo,hi:=box.Bounds();idx.add(lo,hi)}
 for q:=0;q<2000;q++{box:=boxes[random.Intn(len(boxes))];box.Center=box.Center.Add(placement.Vector{random.Float64()*8-4,random.Float64()*8-4,random.Float64()*8-4});expected:=false;for _,b:=range boxes{if box.Overlaps(b){expected=true;break}};lo,hi:=box.Bounds();actual:=idx.any(lo,hi,func(i int)bool{return box.Overlaps(boxes[i])});if actual!=expected{t.Fatal("box mismatch",q)}
 point:=box.Center;expected=false;for _,b:=range boxes{if polarPointBoxDistance(b,point)<.25*.25{expected=true;break}};margin:=placement.Vector{.25,.25,.25};actual=idx.any(point.Sub(margin),point.Add(margin),func(i int)bool{return polarPointBoxDistance(boxes[i],point)<.25*.25});if actual!=expected{t.Fatal("point mismatch",q)}}
 idx.sequence=math.MaxUint32;lo,hi:=boxes[0].Bounds();if !idx.any(lo,hi,func(i int)bool{return i==0}){t.Fatal("query marker overflow")}
}
