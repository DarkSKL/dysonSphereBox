package blueprint
import("testing";"bytes";"compress/gzip";"strings";"errors")
func TestResourceLimitsRemainBounded(t *testing.T){
 check:=func(e error){t.Helper();var bp *Error;if !errors.As(e,&bp)||bp.Code!="BP_E_TOO_LARGE"{t.Fatalf("expected explicit resource limit, got %v",e)}}
 if MaxBuildingCount!=300000||MaxTextBytes!=8<<20||maxPayloadBytes!=64<<20{t.Fatal("resource contract changed")}
 _,e:=encodeBinary(Document{Areas:make([]Area,1),Buildings:make([]Building,MaxBuildingCount+1)});check(e)
 _,e=Decode("BLUEPRINT:"+strings.Repeat("x",MaxTextBytes),false);check(e)
 var buffer bytes.Buffer;w,_:=gzip.NewWriterLevel(&buffer,gzip.BestSpeed);chunk:=make([]byte,1<<20);for i:=0;i<65;i++{if _,e=w.Write(chunk);e!=nil{t.Fatal(e)}};if e=w.Close();e!=nil{t.Fatal(e)};_,e=unzip(buffer.Bytes());check(e)
}
