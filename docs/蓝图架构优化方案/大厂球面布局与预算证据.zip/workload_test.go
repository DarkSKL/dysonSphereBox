package build
import("context";"fmt";"testing";"DysonSphereBox/helper/blueprint/build/placement")
func TestPowerRespectsAllSplitterSelections(t *testing.T){
 catalog,e:=placement.LoadCatalog();if e!=nil{t.Fatal(e)}
 for _,model:=range []int16{38,39,40}{t.Run(fmt.Sprint(model),func(t *testing.T){b,_:=newBuilder(Setting{});gate:=b.make(2020,0,0,0);gate.record.ModelIndex=model;encoding:=newPlanarRuleEncoding();index,e:=newConnectedPowerIndexForEncoding(context.Background(),b,encoding);if e!=nil{t.Fatal(e)};world,e:=index.world(gate.a);if e!=nil{t.Fatal(e)};profile,_:=catalog.SplitterProfile(2020,model);selection,e:=encoding.colliderBox(vector{world[0],world[1],world[2]},gate.record.Yaw,profile.Selection);if e!=nil{t.Fatal(e)};nativeShapes,_:=catalog.Shapes(2020,model);native:=[]placement.Box{};for _,s:=range nativeShapes{box,_:=encoding.colliderBox(vector{world[0],world[1],world[2]},gate.record.Yaw,s);native=append(native,box)}
 verified:=0;for x:=-4.;x<=4;x+=.25{for y:=-4.;y<=4;y+=.25{point:=vector{x,y,0};_,boxes,e:=index.poleGeometry(point);if e!=nil{t.Fatal(e)};inside,original:=false,false;for _,box:=range boxes{inside=inside||box.Overlaps(selection);for _,other:=range native{original=original||box.Overlaps(other)}};if inside&&!original{ok,e:=index.available(point);if e!=nil||ok{t.Fatal("pole entered reserved selection",point,e)};verified++}}};if verified==0{t.Fatal("no regression gap found")};t.Log("selection-only pole locations rejected",verified)})}
}

func TestWorkloadBudgetsAndConcurrency(t *testing.T){
 small:=context.WithValue(context.Background(),generationWorkloadKey{},2047);large:=context.WithValue(context.Background(),generationWorkloadKey{},2048);b:=&builder{}
 if generationBuildingBudget(small)!=200000||generationBuildingBudget(large)!=300000{t.Fatal("building budgets")}
 if b.candidateWorkers(large,100)>4||b.candidateWorkers(large,1)!=1{t.Fatal("automatic concurrency")}
 explicit:=context.WithValue(large,candidateConcurrencyKey{},7);if b.candidateWorkers(explicit,100)!=7{t.Fatal("explicit concurrency lost")}
 b.preview=&generationPreview{protocol:3};if b.candidateWorkers(explicit,100)!=1{t.Fatal("legacy preview serialization")}
}
