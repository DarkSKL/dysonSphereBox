import {createApp, reactive} from 'vue'
import {createAlgorithmViz} from '../src/packages/algorithm-viz/src'
import {useAlgorithmFeed} from '../src/composables/dysonSphere/useAlgorithmFeed'
import {observeFactoryGeneration} from '../src/pages/services/dysonSphere/factory-progress'

const root = window as any
let listener: (event: unknown) => void
const journal: any[] = []
root.runtime = {EventsOnMultiple: (_: string, fn: typeof listener) => { listener = fn; return () => {} }}
root.go = {factory: {Service: {ReadGenerationProgress: async (_: string, after: number) => ({events: journal.slice(after, after + 16), next: journal.length, complete: false})}}}
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))
const check = (v: unknown, message: string) => {if (!v) throw Error(message)}
const taskId = 'retirement-integration'
const w = reactive({generationTaskId: taskId, generating: true, code: '', previewRevision: 0, replay: false, generated: null as any})
let viz: any, feed: any
createApp({setup() {feed = useAlgorithmFeed(w as any, () => viz); return () => null}}).mount('#app')
const container = document.createElement('div'); container.style.cssText = 'width:100vw;height:100vh'; document.body.append(container)
viz = createAlgorithmViz(container, {quality: 'low', speed: 8}); root.viz = viz
const observe = observeFactoryGeneration(taskId, () => {}, undefined, true)
let sequence = 0; const candidates = new Map<string, number>()
function emit(kind: string, candidateId = '', extra: any = {}, live = true) {
  const event: any = {taskId, stage: 'routing', message: '', current: 0, total: 0, protocolVersion: 4, sequence: ++sequence, kind, ...extra}
  if (candidateId) {const n = (candidates.get(candidateId) ?? 0) + 1; candidates.set(candidateId, n); Object.assign(event, {candidateId, candidateSequence: n})}
  journal.push(event); if (live) listener(event)
}
function operations(start: number, count: number, temporary = true) {
  return Array.from({length: count}, (_, n) => ({type: 'add', objectId: 'b' + (start+n), building: {
    index: temporary ? -1 : start+n, itemId: 2001, modelIndex: 35, areaIndex: 0, productionIndex: -1, isTemporary: temporary,
    localOffset: {x: (start+n)%64, y: Math.floor((start+n)/64), z: 0}, localOffset2: {x: (start+n)%64, y: Math.floor((start+n)/64), z: 0},
    yaw: 0, yaw2: 0, tilt: 0, tilt2: 0, pitch: 0, pitch2: 0, inputFromSlot: -1, outputToSlot: -1,
  }}))
}
async function until(fn: () => boolean, ms=10000) {const start=performance.now(); while(!fn()){if(performance.now()-start>ms) throw Error('timeout '+JSON.stringify(viz.getProgress())); await delay(20)}}
async function run() {
  check(viz.supported, 'WebGL unavailable')
  emit('search-start'); emit('candidate-plan','',{candidates:Array.from({length:200},(_,i)=>({id:'c'+i,ordinal:i+1}))})
  check(viz.getProgress().candidates===0,'planned platforms allocated')
  emit('candidate-start','old',{candidateOrdinal:1})
  emit('preview-delta','old',{coordinateSystem:'layout-grid-v1',operations:operations(0,128)})
  await until(()=>viz.getProgress().objects===128 && viz.getProgress().pending===0 && viz.getProgress().animating===0)
  viz.setPaused(true)
  for(let i=128;i<50176;i+=128) emit('preview-delta','old',{coordinateSystem:'layout-grid-v1',operations:operations(i,128)},false)
  // 真实补页路径：暂停渲染、积压超过旧门限，仍须读取后面的淘汰控制事件。
  emit('candidate-finish','old',{candidateStatus:'rejected'},false)
  emit('candidate-start','next',{candidateOrdinal:2},false)
  emit('preview-delta','next',{coordinateSystem:'layout-grid-v1',operations:operations(0,128)},false)
  await observe.drain()
  const afterDrain=viz.getProgress(); check(afterDrain.pending===128,'old queue blocks or survives retirement'); check(afterDrain.falling===1,'no immediate fall')
  await until(()=>viz.getProgress().candidates===1 && viz.getProgress().objects===0)
  check(viz.getProgress().pending===128,'paused new candidate was consumed')
  viz.beginCandidate('old',1);viz.enqueue({candidateId:'old',operations:[{type:'add',id:'late',building:{itemId:2001,x:0,y:0,z:0}}]})
  check(viz.getProgress().candidates===1 && viz.getProgress().pending===128,'retired candidate resurrected')
  emit('candidate-finish','next',{candidateStatus:'valid'})
  const areas=[{index:0,parentIndex:-1,tropicAnchor:0,areaSegments:200,anchorLocalOffset:{x:0,y:0},size:{x:64,y:4}}]
  emit('preview-snapshot','next',{coordinateSystem:'blueprint-area-local-v1',snapshotRevision:1,chunkCount:1,chunkIndex:0,areas,operations:operations(0,128,false)})
  w.generated={winnerCandidateId:'next'}
  emit('preview-complete','next',{coordinateSystem:'blueprint-area-local-v1',winnerCandidateId:'next',snapshotRevision:1,chunkCount:1,buildingCount:128,batchCount:1})
  viz.flush(); await until(()=>viz.getProgress().objects===128 && viz.getProgress().pending===0 && viz.getProgress().animating===0)
  check(feed.notice.value==='', 'feed protocol failure: '+feed.notice.value)
  root.result={passed:true,events:sequence,abandonedQueued:50048,afterDrain,final:viz.getProgress(),notice:feed.notice.value}; observe()
}
run().catch(error=>{root.result={passed:false,error:String(error),stack:error.stack,progress:viz.getProgress(),notice:feed.notice.value};observe()})
