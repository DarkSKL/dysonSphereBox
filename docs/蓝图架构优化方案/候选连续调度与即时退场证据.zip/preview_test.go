package preview
import "testing"
func TestDiscardKeepsProtocolCounters(t *testing.T){calls:=0;n:=New(func(Frame,[]Operation){calls++});n.Sync(Scene{Objects:[]Object{{ID:"a",Building:Building{ItemID:2001}}},Frame:Frame{CoordinateSystem:LayoutCoordinates}});before:=n.BatchCount();if before==0||len(n.current)!=1{t.Fatal(before)};n.Discard();if calls!=before||n.BatchCount()!=before||n.current!=nil||n.order!=nil||n.frame.CoordinateSystem!=""{t.Fatal("discard changed protocol or retained state")}}
