package search

import("context";"errors";"reflect";"sync/atomic";"testing";"time")

func TestStreamRefillsBeforeSlowCandidate(t *testing.T){
 ctx,cancel:=context.WithTimeout(context.Background(),time.Second);defer cancel();release:=make(chan struct{});third:=make(chan struct{});done:=make(chan error,1);var active,peak atomic.Int32;var got []int
 go func(){done<-Stream(ctx,ctx,[]int{0,1,2,3,4},2,func(ctx context.Context,i,v int)int{n:=active.Add(1);for old:=peak.Load();n>old&&!peak.CompareAndSwap(old,n);old=peak.Load(){};defer active.Add(-1);if i==0{select{case<-release:case<-ctx.Done():}};if i==2{close(third)};return v},func(i,out int)error{if i!=out{t.Errorf("index %d result %d",i,out)};got=append(got,out);return nil})}()
 select{case<-third:case<-ctx.Done():t.Fatal("free slot did not start third job")};close(release);if e:=<-done;e!=nil{t.Fatal(e)};if peak.Load()>2||!reflect.DeepEqual(got,[]int{0,1,2,3,4}){t.Fatal(peak.Load(),got)}
}
func TestStreamPrivateStopPreservesCompleted(t *testing.T){
 parent:=context.Background();ctx,cancel:=context.WithCancel(parent);var called atomic.Int32;var got []int
 e:=Stream(parent,ctx,[]int{0,1,2,3,4,5},1,func(ctx context.Context,i,v int)int{called.Add(1);if i==2{cancel()};return v},func(i,out int)error{got=append(got,out);return nil})
 if e!=nil||called.Load()!=3||!reflect.DeepEqual(got,[]int{0,1,2}){t.Fatal(e,called.Load(),got)}
}
func TestStreamParentCancelDiscards(t *testing.T){
 parent,cancel:=context.WithCancel(context.Background());var reduced int;e:=Stream(parent,context.Background(),[]int{0,1,2},2,func(ctx context.Context,i,v int)int{cancel();<-ctx.Done();return v},func(i,out int)error{reduced++;return nil});if !errors.Is(e,context.Canceled)||reduced!=0{t.Fatal(e,reduced)}
}
func TestStreamReducerError(t *testing.T){sentinel:=errors.New("stop");e:=Stream(context.Background(),context.Background(),[]int{0,1},1,func(ctx context.Context,i,v int)int{return v},func(i,v int)error{return sentinel});if !errors.Is(e,sentinel){t.Fatal(e)}}
