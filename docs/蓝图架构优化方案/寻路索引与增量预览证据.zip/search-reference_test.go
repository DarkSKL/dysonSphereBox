package build
import("container/heap";"context";"math")
func (env *transportEnvironment) findTransportDestinationPathReference(ctx context.Context, start vector, candidates []transportDestination, source, target *placed) ([]vector, int, int) {
	env.searchCalls++
	steps := 0
	defer func() {
		env.totalExpanded += steps
		env.maxExpanded = max(env.maxExpanded, steps)
		recordPerformanceSearch(ctx, steps, false)
	}()
	inside := func(v vector) bool {
		return v.x >= env.minimum.x && v.x <= env.maximum.x && v.y >= env.minimum.y && v.y <= env.maximum.y && v.z >= 0 && v.z <= transportMaxHeight && !env.reservedByOther(v, source, target)
	}
	if ctx.Err() != nil || !inside(start) {
		return nil, -1, 0
	}
	goals := make([]vector, 0, len(candidates))
	goalSet := make(map[vector]int, len(candidates))
	for i, candidate := range candidates {
		if !inside(candidate.point) || candidate.cost < 0 || math.IsNaN(candidate.cost) || math.IsInf(candidate.cost, 0) || candidate.length < 0 || env.blocked[beltCell(candidate.point)] && (candidate.reused == nil || candidate.reused.a != candidate.point) {
			continue
		}
		old, exists := goalSet[candidate.point]
		if !exists {
			goals = append(goals, candidate.point)
		}
		if !exists || candidate.cost < candidates[old].cost || candidate.cost == candidates[old].cost && candidate.length < candidates[old].length {
			goalSet[candidate.point] = i
		}
	}
	if len(goals) == 0 {
		return nil, -1, 0
	}
	// 去重后的目标及获选后缀在本次搜索内固定；按原目标顺序预取，避免每个节点重复哈希同一组浮点坐标。
	goalSuffixes := make([]transportDestination, len(goals))
	for i, goal := range goals {
		goalSuffixes[i] = candidates[goalSet[goal]]
	}
	allowed := func(v vector) bool {
		if !inside(v) {
			return false
		}
		goal, exists := goalSet[v]
		return !env.blocked[beltCell(v)] || v == start || exists && candidates[goal].reused != nil
	}
	env.prepareTransportHeuristic(ctx, goals[0])
	// 相邻目标共用势场；预取目标势能，避免每个三维节点重复查询五次目标。
	field := env.corridorPotential
	goalPotentials := make([]float64, len(goals))
	goalHasPotential := make([]bool, len(goals))
	if field != nil && field.version == env.version {
		for i, goal := range goals {
			goalPotentials[i], goalHasPotential[i] = field.distanceAt(goal)
		}
	} else {
		field = nil
	}
	heuristic := func(point vector) (float64, int) {
		cost, length := math.Inf(1), math.MaxInt
		potential, hasPotential := 0., false
		if field != nil {
			potential, hasPotential = field.distanceAt(point)
		}
		for i, goal := range goals {
			suffix := goalSuffixes[i]
			horizontal := math.Abs(point.x-goal.x) + math.Abs(point.y-goal.y)
			vertical := math.Abs(point.z - goal.z)
			length = min(length, int(math.Ceil(horizontal+vertical))+suffix.length)
			if hasPotential && goalHasPotential[i] {
				horizontal = math.Max(horizontal, math.Abs(potential-goalPotentials[i]))
			}
			cost = math.Min(cost, horizontal+env.transportElevationLowerBound(point, goal)+suffix.cost)
		}
		return cost, length
	}
	cost, length := heuristic(start)
	first := &transportPathNode{point: start, score: cost, length: 1, lengthEstimate: 1 + length}
	queue := &transportDestinationQueue{transportPathQueue{first}}
	seen := map[vector]*transportPathNode{start: first}
	serial := 0
	var best *transportPathNode
	bestGoal, bestLength, bestCost := -1, math.MaxInt, math.Inf(1)
	for queue.Len() > 0 && steps < transportSearchLimit {
		if ctx.Err() != nil {
			return nil, -1, steps
		}
		// 几何目标不是虚拟汇点：只有剩余队列的完整下界不能改善时才能结束。
		if best != nil && (queue.transportPathQueue[0].score > bestCost || queue.transportPathQueue[0].score == bestCost && queue.transportPathQueue[0].lengthEstimate >= bestLength) {
			break
		}
		current := heap.Pop(queue).(*transportPathNode)
		current.closed = true
		steps++
		if selected, exists := goalSet[current.point]; exists {
			suffix := candidates[selected]
			cost, length := current.distance+suffix.cost, current.length+suffix.length
			if cost < bestCost || cost == bestCost && length < bestLength {
				best, bestGoal, bestCost, bestLength = current, selected, cost, length
			}
			if env.blocked[beltCell(current.point)] && current.point != start {
				continue
			}
		}
		for _, delta := range []vector{{-1, 0, 0}, {0, 1, 0}, {1, 0, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}} {
			point := vector{current.point.x + delta.x, current.point.y + delta.y, current.point.z + delta.z}
			if !allowed(point) || !env.denseTransportStepClear(current.point, point) {
				continue
			}
			distance, length := current.distance+env.transportStepCost(current.point, point), current.length+1
			old := seen[point]
			if old != nil && (old.closed || old.distance < distance || old.distance == distance && old.length <= length) {
				continue
			}
			remainingCost, remainingLength := heuristic(point)
			if old != nil {
				old.parent, old.distance, old.length = current, distance, length
				old.score, old.lengthEstimate = distance+remainingCost, length+remainingLength
				heap.Fix(queue, old.index)
				continue
			}
			serial++
			node := &transportPathNode{point: point, parent: current, distance: distance, score: distance + remainingCost, order: serial, length: length, lengthEstimate: length + remainingLength}
			seen[point] = node
			heap.Push(queue, node)
		}
	}
	if ctx.Err() != nil || best == nil {
		return nil, -1, steps
	}
	path := make([]vector, best.length)
	for node, i := best, len(path)-1; node != nil; node, i = node.parent, i-1 {
		path[i] = node.point
	}
	return path, bestGoal, steps
}
