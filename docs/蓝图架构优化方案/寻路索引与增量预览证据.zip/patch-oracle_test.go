package preview
import("fmt";"reflect";"testing")
func TestPatchMatchesFullSync(t *testing.T){var deltaA,deltaB []Operation;a:=New(func(_ Frame,ops []Operation){deltaA=append(deltaA,ops...)});b:=New(func(_ Frame,ops []Operation){deltaB=append(deltaB,ops...)});frame:=Frame{CoordinateSystem:LayoutCoordinates};objects:=[]Object{}
 for i:=0;i<500;i++{objects=append(objects,Object{ID:fmt.Sprint(i),Building:Building{ItemID:2001}})};a.Sync(Scene{Frame:frame,Objects:objects});b.Sync(Scene{Frame:frame,Objects:objects});deltaA,deltaB=nil,nil
 objects[17].Building.Yaw=180;changes:=[]Object{objects[17]};for i:=500;i<900;i++{o:=Object{ID:fmt.Sprint(i),Building:Building{ItemID:2001}};objects=append(objects,o);changes=append(changes,o)}
 if !a.Patch(frame,changes){t.Fatal("patch rejected")};b.Sync(Scene{Frame:frame,Objects:objects});if !reflect.DeepEqual(deltaA,deltaB)||!reflect.DeepEqual(a.current,b.current)||!reflect.DeepEqual(a.order,b.order){t.Fatal("patch mismatch")};before:=a.BatchCount();a.Sync(Scene{Frame:frame,Objects:objects});if a.BatchCount()!=before{t.Fatal("patch left stale scene")}
 if a.Patch(Frame{CoordinateSystem:AreaCoordinates},changes){t.Fatal("frame switch must fallback")};a.Discard();if a.Patch(frame,changes){t.Fatal("discard must fallback")}
}
