package build
import("context";"math";"math/rand";"reflect";"testing")
func TestSearchIndexParity(t *testing.T){
 r:=rand.New(rand.NewSource(912876));source,target,foreign:=&placed{},&placed{},&placed{}
 for c:=0;c<220;c++{offset:=0.;if c%5==0{offset=.25}
 env:=transportEnvironment{minimum:vector{-12,-9,0},maximum:vector{12,9,32},blocked:map[vector]bool{},reserved:map[vector]map[*placed]bool{},preferCorridor:c%2==0,beltCorridors:map[[2]int]bool{}}
 if c%3==0 {env.densePorts=&denseRoutePortIndex{edges:map[[2]vector]bool{},strictBelts:c%6==0}}
 for n:=0;n<450;n++{p:=vector{float64(r.Intn(25)-12),float64(r.Intn(19)-9),float64(r.Intn(7))};env.blocked[p]=true;if n%8==0{env.reserved[p]=map[*placed]bool{foreign:true}};if n%3==0{env.beltCorridors[beltColumn(p)]=true}}
 start:=vector{-10+offset,-7+offset,offset};goals:=[]transportDestination{}
 for n:=0;n<8;n++{g:=transportDestination{point:vector{float64(r.Intn(20)-8)+offset,float64(r.Intn(15)-7)+offset,float64(r.Intn(6))+offset},cost:float64(r.Intn(16))/4,length:r.Intn(6)};if n%3==0{g.reused=&placed{a:g.point};env.blocked[beltCell(g.point)]=true};goals=append(goals,g)}
 if c%4==0{goals=append(goals,goals[0])}
 if c%3==0 { for z:=0;z<25;z++{goals=append(goals,transportDestination{point:vector{9+offset,5+offset,float64(z)+offset},cost:float64(z)*1.5+.75,length:z+1})}}
 a,ai,an:=env.findTransportDestinationPathReference(context.Background(),start,goals,source,target);b,bi,bn:=env.findTransportDestinationPathWithSuffix(context.Background(),start,goals,source,target)
 if ai!=bi||an!=bn||!reflect.DeepEqual(a,b){t.Fatalf("case %d path/index/expansions changed: %d/%d %d/%d",c,ai,bi,an,bn)}
 }
}
func TestSearchKeyBoundaries(t *testing.T){
 indices:=map[uint64]vector{}
 for _,x:=range []float64{-(1<<20),-(1<<20)+1,-1,0,1,(1<<20)-2,(1<<20)-1}{for _,y:=range []float64{-(1<<20),-1,0,1,(1<<20)-1}{for z:=-1;z<=33;z++{p:=vector{x,y,float64(z)};key:=transportSearchKey(p);if old,ok:=indices[key];ok && old!=p{t.Fatal("key collision",old,p)};indices[key]=p}}}
 for _,start:=range []vector{{.25,0,0},{0,.25,0},{0,0,.25},{math.Inf(1),0,0},{1<<21,0,0}}{idx:=newTransportSearchIndex(start,vector{-10,-10,0},vector{10,10,32});if idx.integer!=nil{t.Fatal("must fallback",start)}}
 ctx,cancel:=context.WithCancel(context.Background());cancel();env:=transportEnvironment{minimum:vector{-10,-10,0},maximum:vector{10,10,32}};p,i,n:=env.findTransportDestinationPathWithSuffix(ctx,vector{},[]transportDestination{{point:vector{1,1,0}}},nil,nil);if p!=nil||i!=-1||n!=0{t.Fatal("cancelled search emitted path")}
}
func TestHeuristicGoalDominance(t *testing.T){
 random:=rand.New(rand.NewSource(34579));env:=transportEnvironment{densePorts:&denseRoutePortIndex{}}
 evaluate:=func(point vector,goals []transportDestination,indices []int)(float64,int){cost,length:=math.Inf(1),math.MaxInt;for _,i:=range indices{g:=goals[i];horizontal:=math.Abs(point.x-g.point.x)+math.Abs(point.y-g.point.y);cost=min(cost,horizontal+env.transportElevationLowerBound(point,g.point)+g.cost);length=min(length,int(math.Ceil(horizontal+math.Abs(point.z-g.point.z)))+g.length)};return cost,length}
 for c:=0;c<400;c++{goals:=[]transportDestination{};all:=[]int{};for col:=0;col<4;col++{offset:=random.Float64()*3;for z:=0;z<=32;z++{if random.Intn(7)==0{continue};g:=transportDestination{point:vector{float64(col)*2,7,float64(z)},cost:offset+1.5*float64(z),length:z+2};if c%2==1{g.cost+=random.Float64()*10;g.length+=random.Intn(5)};all=append(all,len(goals));goals=append(goals,g)}};indices:=transportHeuristicGoals(goals);if len(indices)==0||len(indices)>=len(goals){t.Fatal("dominance ineffective",len(indices),len(goals))}
 for n:=0;n<100;n++{point:=vector{random.Float64()*1000-500,random.Float64()*100-50,random.Float64()*32};a,al:=evaluate(point,goals,all);b,bl:=evaluate(point,goals,indices);if math.Abs(a-b)>1e-10||al!=bl{t.Fatalf("lower bound changed %g/%g %d/%d",a,b,al,bl)}}}
}
func BenchmarkSearchIndex(b *testing.B){for _,indexed:=range []bool{false,true}{name:="reference";if indexed{name="indexed"};b.Run(name,func(b *testing.B){env:=transportEnvironment{minimum:vector{-60,-20,0},maximum:vector{60,20,32},blocked:map[vector]bool{}};for y:=-20;y<=20;y++{for z:=0;z<=32;z++{env.blocked[vector{0,float64(y),float64(z)}]=true}}
 start:=vector{-50,0,0};goals:=[]transportDestination{{point:vector{50,0,0}}};b.ResetTimer();for n:=0;n<b.N;n++{if indexed{env.findTransportDestinationPathWithSuffix(context.Background(),start,goals,nil,nil)}else{env.findTransportDestinationPathReference(context.Background(),start,goals,nil,nil)}}})}}
